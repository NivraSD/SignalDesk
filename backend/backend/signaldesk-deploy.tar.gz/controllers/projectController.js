const claudeService = require("../config/claude");

// This file is just a placeholder for now
// The actual controller logic is in the routes file
// We'll refactor this later

module.exports = {};
